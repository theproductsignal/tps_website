# Build the Signal - Build your own prototype

Work through a product problem, make your own decisions, and turn them into a clickable prototype. Follow along with the exercise using your own user, idea, and trade-offs. No coding background is required; you will review the product while Codex implements it.

**Start with your guide:** [Windows](docs/GUIDE_WINDOWS.md) | [Mac](docs/GUIDE_MAC.md)

## The workflow

1. Think through the [Miro board](docs/MIRO_BOARD_TEMPLATE.md), then export it as a PDF.
2. Give ChatGPT the PDF, the blank [input template](episode_input_template.md), and prompt A in [the prompt pack](docs/WORKFLOW_PROMPTS.md).
3. Review the filled input, give ChatGPT corrections, and regenerate the complete file with prompt B. Repeat until it reflects your decisions.
4. Save the finalized `episode_input_template.md` in this folder. Ask Codex to produce `briefs/episode_brief.json` with prompt C. Review it before proceeding.
5. Ask Codex to plan, approve the plan, and build using [CODEX_MASTER_PROMPT.md](CODEX_MASTER_PROMPT.md).
6. Test the prototype, critique what you see, and finish with an audit using prompts D and E.

The `episode_` filenames keep the handoff familiar when following along. They contain **your project decisions**; you do not need to produce an episode.

## What is included

| File or folder | Purpose |
| --- | --- |
| `docs/GUIDE_WINDOWS.md` / `docs/GUIDE_MAC.md` | Setup and end-to-end instructions |
| `docs/MIRO_BOARD_TEMPLATE.md` | Board sections to recreate in Miro |
| `docs/WORKFLOW_PROMPTS.md` | Copy-and-paste prompts for extraction, revision, brief, critique, and audit |
| `episode_input_template.md` | Human-readable decisions; blank until you complete the exercise |
| `briefs/episode_brief.example.json` | Blank structure Codex uses to create the build brief |
| `CODEX_MASTER_PROMPT.md` | Plan and implement your approved brief |
| `src/`, `index.html`, `vite.config.js` | Complete working React/Vite starter |
| `package.json`, `package-lock.json` | Commands and repeatable dependencies |
| `inputs/README.md` | Where to save your exported board |

This is already a React project. Extract the ZIP and use this folder directly. There is no need to create a second Vite project or copy these files into another app.

## The starter screen

The initial screen is a replaceable demonstration: three options, explanations, selection, and reset. It is not a recommended solution to your problem. Your brief may call for a guided flow, comparison tool, planner, or another small experience.

Use fixture data and local state for this exercise. The prototype runs on your computer; it is not a deployed service. Refreshing the starter clears its selection. No API key is needed by the sample app.

## Commands

Run in the folder containing `package.json`, with Node 22.12 or newer:

```sh
npm ci
npm run dev
```

Open the **Local** URL printed in the terminal. Keep that terminal running. Stop it with **Ctrl+C**. On Windows PowerShell, use `npm.cmd` if `npm.ps1` is blocked.

The kit also supports `npm run build` and `npm run preview` for an optional production check. The guided exercise ends with the local prototype and audit; publishing, Git, and GitHub are not required.

For a new idea, extract a fresh copy of the ZIP. Keep your completed project separately.
