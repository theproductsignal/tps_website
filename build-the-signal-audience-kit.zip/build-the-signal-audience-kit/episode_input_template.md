# My prototype - decision input

Status: DRAFT
Version: 1
Source: inputs/miro-board.pdf

Use your own decisions. Replace each `[To fill]`. Write `Not applicable - reason` for an irrelevant field. Mark missing information `UNRESOLVED`; do not invent decisions. Change status to FINAL only after your review.

## 1. Problem and context
- Working title: [To fill]
- Product or service context: [To fill]
- Question to explore: [To fill]
- Why this matters now: [To fill]

## 2. User and outcomes
- Focus user: [To fill]
- Situation or trigger: [To fill]
- Job to be done: [To fill]
- Desired user outcome: [To fill]
- Desired business or organizational outcome: [To fill]

## 3. Constraints and assumptions
- Hard constraints: [To fill]
- Trust or ethical constraints: [To fill]
- Assumptions accepted for this prototype: [To fill]
- Facts to verify later: [To fill]

## 4. Diagnosis
- Framework used, if any: [To fill]
- Current experience and root problem: [To fill]
- Design principle: [To fill]
- How-might-we question: [To fill]

## 5. Ideas and decision
- Alternatives considered: [To fill]
- Chosen idea: [To fill]
- Why this idea over the alternatives: [To fill]
- Hypothesis to test: [To fill]
- Biggest trade-off: [To fill]
- Evidence that would make us abandon the idea: [To fill]

## 6. One complete user loop
- Entry screen and context: [To fill]
- User action: [To fill]
- System response: [To fill]
- Visible consequence or value: [To fill]
- Recovery, change, or reset: [To fill]
- Required alternate or failure state: [To fill]

## 7. Prototype boundaries
- Experience type (for example, guided flow or comparison tool): [To fill]
- Maximum screens or major states: [To fill]
- Must work: [To fill]
- Can be simulated: [To fill]
- Explicit non-goals: [To fill]
- Required states: [To fill]
- Sample scenarios and their expected differences: [To fill]
- Acceptance checks (action -> expected result): [To fill]

## 8. Learning plan
- Three questions this prototype should help answer: [To fill]
- Leading success signal: [To fill]
- Guardrail metric or undesirable effect to watch: [To fill]
- Riskiest assumption: [To fill]
- Other risks: [To fill]

## 9. Visual direction
- Tone and hierarchy: [To fill]
- Accessibility needs: [To fill]
- Brand-use restrictions: [To fill]
- Reference patterns, not copied interfaces: [To fill]

## 10. Review and evidence
- Source map (section -> PDF page and frame): [To fill]
- Contradictions or unreadable notes: [To fill]
- Open questions: [To fill]
- Changes made during review: [To fill]
- Final review date: [To fill]

Before marking FINAL, confirm the target user, chosen idea, hypothesis, complete flow, constraints, non-goals, and acceptance checks are explicit. Resolve blocking questions and distinguish accepted assumptions from known facts.
