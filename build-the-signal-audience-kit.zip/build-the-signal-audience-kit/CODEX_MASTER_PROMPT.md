# Plan and build your prototype

Use this after reviewing `briefs/episode_brief.json`. Copy the planning prompt first; send the build prompt only after the plan represents your decisions.

## 1. Plan

```text
You are my implementation partner. Work in this existing React/Vite project.
Read episode_input_template.md and briefs/episode_brief.json.
Verify the input is FINAL, review.status is 'approved', and review.input_version matches the input version. If any check fails or the documents conflict, explain the issue before coding.

Do not write code yet. Return:
1. The product decision in five bullets.
2. Contradictions, unresolved assumptions, or technical limitations.
3. The smallest complete clickable flow within the brief's screen/state limit.
4. What will work, what will be simulated, and what is out of scope.
5. The files you expect to modify and how you will verify the acceptance checks.

The existing three-path UI is replaceable example content, not a requirement. Preserve working React/Vite setup and reuse only controls that fit my brief. Do not scaffold another project.
Wait for my approval before implementing.
```

Review the user, chosen idea, hypothesis, consequence of each action, recovery/reset, and non-goals. Correct the plan before proceeding.

## 2. Build

```text
I approve the plan. Implement the first functional pass in this project.

- Follow briefs/episode_brief.json. Keep the user, chosen idea, hypothesis, constraints, non-goals, and screen/state limit intact.
- Complete one user loop from entry to meaningful outcome, with recovery/reset and the alternate states required by the brief.
- Use plausible fixture data and local state. Label simulated behavior honestly. Do not add a backend, authentication, payments, database, external API, or API key requirement for this exercise. If the brief cannot be tested without one, explain the conflict so I can revise the scope first.
- Use existing dependencies. Explain why before adding a package. Preserve the lockfile and npm scripts.
- Replace starter copy and controls that do not fit the idea. Make every visible primary action work. Different scenarios must differ in the ways specified by the brief.
- Use clear hierarchy, descriptive labels, semantic HTML, visible keyboard focus, and readable contrast. Keep the layout usable on desktop and a narrow phone-sized window.
- Use an original concept interface without copying production brand assets. Show only information that helps the user make the relevant decision.
- Verify the acceptance checks in the local preview when available. Report exactly what was tested and any manual checks needed.
- Do not use Git, deploy, or run a production build/preview server as part of this guided exercise.

When the primary flow works, stop and summarize what changed, the assumptions encoded, simulated behavior, and what remains. Keep the getting-started documentation intact; save a short five-step walkthrough and three key assumptions in DEMO_NOTES.md.
```

Next, test the product yourself and use prompts D/E in [the prompt pack](docs/WORKFLOW_PROMPTS.md) to critique and audit it.
