# Your Miro board - nine frames

Create nine frames in Miro, numbered 0-8. Add the heading as text **inside** each frame so it appears in the export. This file is a guide for recreating the board, not an importable Miro template.

Work alone or with a partner. Complete frames 0-6 before building. In frames 7-8, record what you currently assume or expect to learn; return after testing to record actual findings. Mark anything that cannot yet be known as pending.

## 0. Define the exercise
- What question are you exploring?
- What context matters?
- What small interactive experience should exist by the end?
- Keep the scope to one focus user, one chosen idea, and one complete loop.

## 1. Clarify the user and outcome
- Who is the focus user, and what situation triggers their need?
- What are they trying to accomplish?
- What user and business outcomes matter?
- What constraints must your solution respect?

## 2. Diagnose the problem
- Map the current experience using a framework that helps you think.
- Identify the broken step or root cause.
- Write a design principle and a how-might-we question.
- Separate evidence from assumptions.

## 3. Explore alternatives
- Generate an obvious idea, a structural change, and an unexpected alternative.
- If working with a partner, write independently before discussing.
- Cluster related ideas without prematurely choosing a winner.

## 4. Make a decision
- Compare user value, organizational value, learning value, and implementation effort.
- Write: We chose ___ because ___.
- Record the hypothesis, biggest trade-off, and what would disprove the idea.
- Label the chosen idea clearly. Preserve rejected alternatives as alternatives.

## 5. Sketch the smallest complete loop
- Entry or trigger -> user action -> system response -> visible value.
- Add change, recovery, or reset.
- Specify the alternate/failure state needed to test your claim.
- Write an observable outcome for every primary action.

## 6. Define the build boundaries
- Must work; can be simulated; out of scope.
- Maximum screens or major states; required states; sample scenarios.
- Visual direction, accessibility needs, and brand restrictions.
- Three learning questions, a success signal, and a guardrail.
- Resolve the decision here; the next step is PDF -> reviewed Markdown -> JSON.

## 7. Keep a decision log
- Assumption accepted for the prototype.
- Correction and the reason for it.
- What needs later validation.

## 8. Capture what you learn
- What might this prototype reveal? After testing, what did it reveal?
- What would you test with real users next?
- What did you intentionally leave out?
- What would be difficult in a real implementation?

## Export and check

Use Miro's board export menu to save a PDF. Frames become pages; check their order and keep all needed content inside frames. Export quality and permissions depend on your Miro access. See [Miro's export instructions](https://help.miro.com/hc/en-us/articles/360017572754-How-to-export-your-board).

Save it as `inputs/miro-board.pdf`. Open the file and check every page at readable zoom. Important information should be on the board itself, not only in a conversation or comment. If ChatGPT cannot read the PDF, provide clear images of the affected frames or paste a labeled transcript.
