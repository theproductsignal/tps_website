# Build your own prototype - Windows

Your goal is one small experience that tests your product idea. You make the decisions; ChatGPT helps organize them and Codex implements them. You can work alone or with a partner.

You need this extracted kit, Miro access that allows a readable export, ChatGPT with file uploads, Codex access in the desktop app, Node.js, and a browser. Account availability and limits vary. No GitHub account or coding background is required for this workflow.

## 1. Open and check the starter

1. Right-click the downloaded ZIP and choose **Extract All**. Put the extracted folder somewhere easy to find, such as Documents. Open the inner `build-the-signal-audience-kit` folder containing `package.json` and `src`.
2. Install Node.js LTS from [nodejs.org](https://nodejs.org/en/download). This kit requires Node 22.12 or newer. Close and reopen your terminal after installation.
3. Open **PowerShell** in the project folder: in File Explorer, open the folder, type `powershell` in its address bar, and press Enter. Run these lines one at a time:

```powershell
node --version
npm.cmd --version
npm.cmd ci
npm.cmd run dev
```

`npm.cmd` avoids the common PowerShell `npm.ps1` execution-policy error. You do not need to change the execution policy. This guide uses Windows-native tools; WSL is not needed.

Open the **Local** URL printed in the terminal, usually `http://localhost:5173/`. The initial screen has three paths. Try selecting a path, opening **Why this?**, closing it, and resetting. This screen is only a working example; your idea can use a different flow.

Keep the terminal open while using the prototype. **Ctrl+C** stops the server (Control+C on Mac, not Command+C). To restart it later, return to this folder and run `npm.cmd run dev`. There is no need to create a new Vite project.

## 2. Think through the Miro board

Recreate the nine sections in [MIRO_BOARD_TEMPLATE.md](MIRO_BOARD_TEMPLATE.md). Use your own problem, user, ideas, and trade-offs. Work through all frames; mark later learning as pending rather than inventing results. Clearly label the chosen idea and rejected alternatives.

Export the board to PDF and save it as `inputs/miro-board.pdf`. Open the PDF and check every frame and note is readable. If the export is cropped or blurry, correct it before continuing.

## 3. Turn the PDF into your input document

In ChatGPT, attach the PDF and the kit's blank `episode_input_template.md`. Paste **prompt A** from [WORKFLOW_PROMPTS.md](WORKFLOW_PROMPTS.md). If file attachment is unavailable for Markdown, paste the template text.

Review the full result against your board. Check the focus user, selected idea, hypothesis, flow, scope, and acceptance checks. Challenge invented assumptions and resolve open questions.

Give ChatGPT your corrections using **prompt B**. It should regenerate the entire document. Repeat until it matches your decisions, then explicitly request FINAL status and provide your review date.

Download or copy the final file into the kit's root, replacing the blank `episode_input_template.md`. Use a plain-text editor such as Notepad. When saving, select **All files**, name it `episode_input_template.md`, and use UTF-8. In File Explorer, enable file-name extensions and check it did not become `.md.txt`. If copying from a code block, copy the Markdown inside it, not the surrounding triple backticks.

**Checkpoint:** the local file says FINAL, has a version, and contains your decisions. ChatGPT's answer alone does not update the file on your computer.

## 4. Open this folder in Codex

Install or open the desktop app, sign in, and choose Codex. Add/open the local project folder containing this kit. Work directly in the local folder; if environment choices appear, choose Local. UI labels may change; see the [official quickstart](https://learn.chatgpt.com/docs/quickstart).

Confirm Codex can see `package.json`, `src`, `episode_input_template.md`, `CODEX_MASTER_PROMPT.md`, and `briefs/episode_brief.example.json` together. Allow the project file access and command execution needed for this exercise when prompted.

## 5. Generate and review the build brief

Paste **prompt C** from [WORKFLOW_PROMPTS.md](WORKFLOW_PROMPTS.md). Codex creates `briefs/episode_brief.json` and stops for your review.

Compare the summary and JSON to your finalized input. Check that no features were added, the complete loop and recovery are included, and simulated behavior is explicit. Request corrections if necessary. Then send the approval message below prompt C; it marks the brief approved.

**Checkpoint:** the real `episode_brief.json` exists with approved status and the matching input version. The `.example.json` file is only the blank structure.

## 6. Plan, then build

Open [CODEX_MASTER_PROMPT.md](../CODEX_MASTER_PROMPT.md). Send its **Plan** prompt first. Review the proposed flow and non-goals. You do not need to understand every code file to judge whether the plan represents your idea.

When satisfied, send its **Build** prompt. Watch the running browser preview as Codex changes the files. If the server stopped, restart it using the command from step 1. Use the terminal's actual Local URL; the port may change.

## 7. Test and critique

Try the prototype as your intended user:

- Can you identify the main action and complete the full loop?
- Does each primary button produce the expected visible result?
- Do required explanations and alternate states work?
- Can you change your decision, recover, or reset?
- Do required scenarios produce the differences in your brief?
- Can you reach and activate controls with Tab and Enter/Space, with visible focus?
- Is the experience usable in a narrow browser window?
- Are simulations understandable, and does the experience test your hypothesis?

Use **prompt D** for a specific issue you observe. Give the steps, actual result, expected result, and why it matters. Retest the fix. You do not need to manufacture a criticism if the flow already works.

If your product decision changes, update and finalize the Markdown, regenerate and approve the JSON, then ask Codex to update the app. This keeps all three in agreement.

## 8. Audit and finish

Send **prompt E**. Read `AUDIT_SUMMARY.md` and complete anything marked not verified. The exercise is complete when the primary loop and recovery work, the critical acceptance checks pass, and the audit honestly records remaining limitations.

Return to Miro frames 7-8 to record what you learned and what you would test next. Keep this folder as your completed project. Start another idea from a fresh ZIP extraction.

## Troubleshooting

| What you see | What to do |
| --- | --- |
| `node` or `npm` not found | Install Node, reopen the terminal, and check the version again. |
| `package.json` missing | Open the inner extracted folder containing `package.json` and `src`. |
| `npm ci` fails | Copy the complete error to Codex. Ask for the smallest setup fix; retain the lockfile. |
| Input or brief missing | Check exact filenames and extensions, and the folder selected in Codex. |
| PDF notes unreadable | Export more readable frames or provide images/a labeled transcript. Do not ask the model to guess. |
| Browser shows an old page | Confirm the server is running for this folder, open its printed Local URL, and refresh. |
| Port 5173 is busy | Use the alternate Local URL printed by Vite. |
| Red error screen | Give Codex the error and ask it to fix the blocking issue without changing the product scope. |
| Generated idea is too broad | Return to the agreed user loop, screen limit, and non-goals. |

Setup references checked November 2, 2026: [OpenAI desktop app](https://learn.chatgpt.com/docs/app), [Node.js downloads](https://nodejs.org/en/download). The linked official documentation is the reference if app menus differ from these instructions.

Windows-specific reference: [official Windows guide](https://learn.chatgpt.com/docs/windows/windows-app).
