# Your board export

Save your Miro export here as `miro-board.pdf`. This file is created by you; no completed board is bundled.

Open it before uploading it to ChatGPT. Check that every frame and sticky note is readable. If notes are missing, add them to the board and export again, or provide a clearly labeled transcript with the PDF.
