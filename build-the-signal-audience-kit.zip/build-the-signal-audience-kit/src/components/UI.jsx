import { X } from 'lucide-react'

export function Badge({ children, tone = 'neutral' }) {
  return <span className={`badge badge--${tone}`}>{children}</span>
}

export function Button({ children, variant = 'primary', className = '', ...props }) {
  return (
    <button className={`button button--${variant} ${className}`} {...props}>
      {children}
    </button>
  )
}

export function Progress({ value }) {
  const safeValue = Math.max(0, Math.min(100, value))
  return (
    <div className="progress" aria-label={`${safeValue}% complete`}>
      <div className="progress__bar" style={{ width: `${safeValue}%` }} />
    </div>
  )
}

export function Modal({ open, title, children, onClose }) {
  if (!open) return null

  return (
    <div className="modal-backdrop" role="presentation" onMouseDown={onClose}>
      <section
        className="modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-title"
        onMouseDown={(event) => event.stopPropagation()}
      >
        <button className="icon-button modal__close" onClick={onClose} aria-label="Close details">
          <X size={18} />
        </button>
        <p className="kicker">WHY THIS APPEARED</p>
        <h2 id="modal-title">{title}</h2>
        {children}
      </section>
    </div>
  )
}
