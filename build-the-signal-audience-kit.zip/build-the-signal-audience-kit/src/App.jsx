import { useState } from 'react'
import { ArrowRight, Check, Info, RotateCcw, Sparkles } from 'lucide-react'
import { episodeConfig } from './episodeConfig.js'
import { Badge, Button, Modal, Progress } from './components/UI.jsx'

function PathCard({ path, selected, onSelect, onExplain }) {
  return (
    <article className={`path-card ${selected ? 'path-card--selected' : ''}`}>
      <div className="path-card__topline">
        <span className="eyebrow">{path.eyebrow}</span>
        {path.recommended && <Badge tone="accent">Recommended</Badge>}
      </div>
      <h3>{path.title}</h3>
      <p>{path.description}</p>
      <div className="path-card__progress-row">
        <Progress value={path.progress} />
        <span>{path.progress}%</span>
      </div>
      <div className="path-card__footer">
        <span className="payoff">{path.payoff}</span>
        <button className="text-button" onClick={() => onExplain(path)}>
          <Info size={16} /> Why this?
        </button>
      </div>
      <Button
        variant={selected ? 'selected' : 'secondary'}
        className="path-card__button"
        onClick={() => onSelect(path.id)}
      >
        {selected ? (
          <>
            <Check size={17} /> Path selected
          </>
        ) : (
          <>
            Choose path <ArrowRight size={17} />
          </>
        )}
      </Button>
    </article>
  )
}

export default function App() {
  const [selectedId, setSelectedId] = useState(null)
  const [explainedPath, setExplainedPath] = useState(null)

  const selectedPath = episodeConfig.paths.find((path) => path.id === selectedId)

  return (
    <main className="app-shell">
      <header className="topbar">
        <div>
          <p className="brand">THE PRODUCT SIGNAL</p>
          <span className="topbar__divider">/</span>
          <span>{episodeConfig.productName}</span>
        </div>
        <Badge>{episodeConfig.prototypeLabel}</Badge>
      </header>

      <section className="hero">
        <div className="hero__copy">
          <p className="kicker">PERSONALIZED NEXT STEP</p>
          <h1>{episodeConfig.headline}</h1>
          <p className="hero__subhead">{episodeConfig.subhead}</p>
        </div>
        <aside className="user-card">
          <div className="avatar" aria-hidden="true">{episodeConfig.user.name[0]}</div>
          <div>
            <strong>{episodeConfig.user.name}</strong>
            <span>{episodeConfig.user.context}</span>
          </div>
        </aside>
      </section>

      <section className="path-grid" aria-label="Available paths">
        {episodeConfig.paths.map((path) => (
          <PathCard
            key={path.id}
            path={path}
            selected={path.id === selectedId}
            onSelect={setSelectedId}
            onExplain={setExplainedPath}
          />
        ))}
      </section>

      <section className={`decision-bar ${selectedPath ? 'decision-bar--active' : ''}`}>
        <div className="decision-bar__icon"><Sparkles size={20} /></div>
        <div>
          <span className="eyebrow">CURRENT DECISION</span>
          <strong>{selectedPath ? selectedPath.title : 'No path selected yet'}</strong>
          <p>
            {selectedPath
              ? 'The prototype now has a committed state. The next screen should make the first action obvious.'
              : 'Choose one path to demonstrate a complete, clickable decision loop.'}
          </p>
        </div>
        {selectedPath && (
          <Button variant="ghost" onClick={() => setSelectedId(null)}>
            <RotateCcw size={17} /> Reset
          </Button>
        )}
      </section>

      <section className="hypothesis">
        <span className="eyebrow">HYPOTHESIS UNDER TEST</span>
        <p>{episodeConfig.hypothesis}</p>
      </section>

      <Modal
        open={Boolean(explainedPath)}
        title={explainedPath?.title ?? ''}
        onClose={() => setExplainedPath(null)}
      >
        <p>{explainedPath?.reason}</p>
        <div className="modal__note">
          <strong>PM check:</strong> Does this explanation feel helpful, manipulative, or overly specific?
        </div>
      </Modal>
    </main>
  )
}
