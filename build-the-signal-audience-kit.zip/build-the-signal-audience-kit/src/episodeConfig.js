export const episodeConfig = {
  prototypeLabel: 'CONCEPT PROTOTYPE',
  productName: 'Signal Paths',
  headline: 'Choose the outcome you want to make progress toward',
  subhead:
    'A neutral demonstration of a personalized decision dashboard. Replace this content and flow with the your own prototype.',
  user: {
    name: 'Jordan',
    context: 'Returning user · 8 months active',
  },
  hypothesis:
    'Giving users a small set of relevant, explainable paths will increase intentional return behavior without relying on blanket incentives.',
  paths: [
    {
      id: 'routine',
      eyebrow: 'LOWEST EFFORT',
      title: 'Keep my routine',
      description: 'Make a familiar behavior easier and more predictable.',
      progress: 70,
      payoff: 'Unlock in 2 actions',
      reason: 'Recommended from your recent pattern and stated preference for convenience.',
      recommended: true,
    },
    {
      id: 'explore',
      eyebrow: 'NEW DISCOVERY',
      title: 'Try something new',
      description: 'Explore an adjacent option with a small, reversible commitment.',
      progress: 35,
      payoff: 'Unlock in 4 actions',
      reason: 'Suggested because you repeat the same choice but occasionally browse alternatives.',
      recommended: false,
    },
    {
      id: 'share',
      eyebrow: 'SOCIAL VALUE',
      title: 'Include someone else',
      description: 'Turn individual progress into a shared moment or benefit.',
      progress: 15,
      payoff: 'Unlock in 5 actions',
      reason: 'Suggested as a lower-frequency path that may create higher emotional value.',
      recommended: false,
    },
  ],
}
